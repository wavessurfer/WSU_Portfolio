
public class L3A {
	public static void main(String[] args) {
		int num1 = 22, num2 = 2;
		int divResult=0;
		char[] chArr = { 'a', 'b', 'c', 'd' };
		divResult = num1 / num2;
		chArr[3] = 'X';
		System.out.println("divResult=" + divResult);
		System.out.println("chArr=" + String.valueOf(chArr));
		}
} 
